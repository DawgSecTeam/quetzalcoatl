sudo ls
doas ls
clear
sudo apt install qemu-guest-agent
clear
sudo apt update
vim .bash_history 
sudo truncate -s 0 /etc/machine-id
sudo rm -f /var/lib/dbus/machine-id 
sudo shutdown -h now
